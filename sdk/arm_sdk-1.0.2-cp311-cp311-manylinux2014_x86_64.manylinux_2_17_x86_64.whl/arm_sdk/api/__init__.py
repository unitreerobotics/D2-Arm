"""对外稳定运动面：``MotionController`` + ``MotionHandle``。

以后加 movel/示教只是加动作，不改此面。
"""

from __future__ import annotations

from .identification import (
    ApplyPayloadResult,
    ClearPayloadResult,
    PayloadIdentificationService,
    PayloadState,
    PayloadSubmitResult,
)
from .motion import Mode, MotionController, MotionHandle, MotionResult, MotionStatus
from ..runtime.identification import IdentificationConfig, IdentificationError

__all__ = [
    "Mode",
    "MotionController",
    "MotionHandle",
    "MotionResult",
    "MotionStatus",
    "PayloadIdentificationService",
    "PayloadState",
    "ClearPayloadResult",
    "ApplyPayloadResult",
    "PayloadSubmitResult",
    "IdentificationConfig",
    "IdentificationError",
]
