"""固件升级（OTA/IAP）—— SDK 的一等能力（BL-6）。

对外入口：``FirmwareUpgrade`` / ``upgrade_firmware``；帧与 CRC 的单一实现在 ``ymodem``，
UDP 发送状态机在 ``transfer``。**仅支持 UDP**（Bootloader 无串口 IAP）。
"""

from __future__ import annotations

from .orchestrator import (
    APP_MAX_SIZE,
    BOOTLOADER_IP,
    BOOTLOADER_PORT,
    FirmwareUpgrade,
    PreflightError,
    UpgradeAborted,
    UpgradeError,
    UpgradeProgress,
    UpgradeResult,
    UpgradeTransferError,
    VerificationError,
    upgrade_firmware,
)

__all__ = [
    "APP_MAX_SIZE",
    "BOOTLOADER_IP",
    "BOOTLOADER_PORT",
    "FirmwareUpgrade",
    "UpgradeError",
    "PreflightError",
    "UpgradeTransferError",
    "UpgradeAborted",
    "VerificationError",
    "UpgradeProgress",
    "UpgradeResult",
    "upgrade_firmware",
]
