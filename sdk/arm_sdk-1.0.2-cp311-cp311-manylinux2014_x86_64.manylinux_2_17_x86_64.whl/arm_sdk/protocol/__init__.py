"""协议层：codec 与生成常量引用。"""

from __future__ import annotations

from . import codec, constants, joint_limits, messages

__all__ = ["codec", "constants", "joint_limits", "messages"]
