"""D2Arm 执行协议常量 —— 自动生成，请勿修改。

协议版本 2.7
"""

from __future__ import annotations

import enum
import struct

PROTOCOL_MAJOR = 2
PROTOCOL_MINOR = 7
HEADER_SIZE = 16
CRC_SIZE = 4
SERIAL_SYNC = bytes.fromhex("4432")

MOTOR_COUNT = 8
JOINT_COUNT = 7
GRIPPER_INDEX = 7
ENTER_BOOTLOADER_MAGIC = 0xCAFEBABE

# 所有整数 little-endian，浮点 IEEE754 binary32
BYTE_ORDER = "<"

# 通用头部字段偏移（与 C 侧 D2ARM_HDR_* 一致）
HEADER_OFFSETS: dict[str, int] = {
    "msg_type": 0,
    "flags": 1,
    "boot_id": 2,
    "session_id": 4,
    "reserved": 6,
    "sequence": 8,
    "timestamp_us": 12,
}


# 0 与 14..255 保留。新增消息需升 minor 版本并同步 generate 与黄金向量。
class Msg_type(enum.IntEnum):
    """0 与 14..255 保留。新增消息需升 minor 版本并同步 generate 与黄金向量。"""


    HELLO = 1
    ACQUIRE = 2
    RENEW = 3
    RELEASE = 4
    MIT_CMD = 5
    TELEMETRY = 6
    SET_LED_EFFECT = 7
    FAULT_RESET = 8
    SET_ENABLE = 9
    SET_NET_CONFIG = 10
    DEVICE_INFO = 11
    ENTER_BOOTLOADER = 12
    GET_NET_CONFIG = 13
    STORAGE_BEGIN = 32
    STORAGE_WRITE_CHUNK = 33
    STORAGE_COMMIT = 34
    STORAGE_READ_CHUNK = 35
    STORAGE_INFO = 36

# 单字节位域。除 bit0 外全部必须为 0。
class Flags(enum.IntEnum):
    """单字节位域。除 bit0 外全部必须为 0。"""


    REQUEST = 0
    RESPONSE = 1

# 所有 response 的统一结果码。0 表示成功。
class Result(enum.IntEnum):
    """所有 response 的统一结果码。0 表示成功。"""


    OK = 0
    DENIED_BUSY = 1
    NOT_READY = 2
    BAD_BOOT = 3
    BAD_SESSION = 4
    FAULT_ACTIVE = 5
    OUT_OF_RANGE = 6
    INTERNAL_ERROR = 7
    BAD_SEQUENCE = 8
    NOT_FINITE = 9
    LIMIT_EXCEEDED = 10
    UNSUPPORTED = 11
    SAFETY_OVERRIDE = 12

# 执行状态。与『物理使能』『业务模式』分开表示。4 态（revision 2.0 起）：值是**算出来的**，判据自上而下命中即返回——① fault_active → FAULT；② 未使能（motors_enabled 为假）→ DISABLED；③ 本会话已收到过被接受的 MIT 且未在本地保持 → RUNNING；④ 其余 → HOLD。**控制权（session_id）不参与判据**——使能是电机级模式切换，与 ACQUIRE 是两件事。值 3 为 revision 2.0 退休的 STOPPING，**不复用**。
class Execution_state(enum.IntEnum):
    """执行状态。与『物理使能』『业务模式』分开表示。4 态（revision 2.0 起）：值是**算出来的**，判据自上而下命中即返回——① fault_active → FAULT；② 未使能（motors_enabled 为假）→ DISABLED；③ 本会话已收到过被接受的 MIT 且未在本地保持 → RUNNING；④ 其余 → HOLD。**控制权（session_id）不参与判据**——使能是电机级模式切换，与 ACQUIRE 是两件事。值 3 为 revision 2.0 退休的 STOPPING，**不复用**。"""


    DISABLED = 0
    HOLD = 1
    RUNNING = 2
    FAULT = 4

# 『为什么不在 RUNNING』。区分『温和兜底』与『真正故障』——前者不报故障，新命令到达即恢复；后者需人工 FAULT_RESET。
class Stop_reason(enum.IntEnum):
    """『为什么不在 RUNNING』。区分『温和兜底』与『真正故障』——前者不报故障，新命令到达即恢复；后者需人工 FAULT_RESET。"""


    NONE = 0
    TARGET_EXPIRED = 1
    LEASE_EXPIRED = 2
    USER_CANCEL = 3
    FAULT = 4

# 0 = 无故障。非 0 时 execution_state 应为 FAULT，需 FAULT_RESET 人工确认才能恢复。仅覆盖 0..6 轴手臂本体；夹爪（第 7 路，可选配件）的故障不进此字段，见 enums.joint_index 与 per-motor status bit3。
# 这是**粗类目**码表，不细分到 11 个电机硬件错误位（欠压/过压/过流/过载/过速/驱动芯片/未标定/其他…）——一个字节放不下多关节多错误。『哪个关节』由 per-motor status 的 bit1(fault)/bit2(overtemp) 指示。各类目的产生判据见协议规范。
# 一个 fault_code 只能表示一个值；多类故障并存时按**上报优先级**取一个：POWER > CONTROL_LOOP_STALE > JOINT_LIMIT > TRACKING_ERROR > ENCODER_INVALID > OVER_TEMP > MOTOR_FAULT > OUTPUT_FAILURE。这是上报优先级，不是安全动作策略（动作分级另定）。revision 2.0 起 `FEEDBACK_INVALID(5)` 与 `OUTPUT_FAILURE(6)` **已退休**（不再产生，号码保留不复用）：反馈离线改成非锁存的『有轴离线』提示（1000 ms 判据），不把设备推进需要人工复位的地方。
class Fault_code(enum.IntEnum):
    """0 = 无故障。非 0 时 execution_state 应为 FAULT，需 FAULT_RESET 人工确认才能恢复。仅覆盖 0..6 轴手臂本体；夹爪（第 7 路，可选配件）的故障不进此字段，见 enums.joint_index 与 per-motor status bit3。
这是**粗类目**码表，不细分到 11 个电机硬件错误位（欠压/过压/过流/过载/过速/驱动芯片/未标定/其他…）——一个字节放不下多关节多错误。『哪个关节』由 per-motor status 的 bit1(fault)/bit2(overtemp) 指示。各类目的产生判据见协议规范。
一个 fault_code 只能表示一个值；多类故障并存时按**上报优先级**取一个：POWER > CONTROL_LOOP_STALE > JOINT_LIMIT > TRACKING_ERROR > ENCODER_INVALID > OVER_TEMP > MOTOR_FAULT > OUTPUT_FAILURE。这是上报优先级，不是安全动作策略（动作分级另定）。revision 2.0 起 `FEEDBACK_INVALID(5)` 与 `OUTPUT_FAILURE(6)` **已退休**（不再产生，号码保留不复用）：反馈离线改成非锁存的『有轴离线』提示（1000 ms 判据），不把设备推进需要人工复位的地方。"""


    NONE = 0
    MOTOR_FAULT = 1
    OVER_TEMP = 2
    ENCODER_INVALID = 3
    JOINT_LIMIT = 4
    FEEDBACK_INVALID = 5
    OUTPUT_FAILURE = 6
    CONTROL_LOOP_STALE = 7
    POWER = 8
    TRACKING_ERROR = 9

# GET_NET_CONFIG 响应里『当前**运行**网络配置为什么是它』的状态。与『保存配置』分开：保存配置可能已写入外部 Flash 但尚未重启生效（见 flags.pending_reboot）。运行配置只可能来自两处——已存记录或编译期默认值，所以这里只需区分默认值的两种成因。
class Net_config_status(enum.IntEnum):
    """GET_NET_CONFIG 响应里『当前**运行**网络配置为什么是它』的状态。与『保存配置』分开：保存配置可能已写入外部 Flash 但尚未重启生效（见 flags.pending_reboot）。运行配置只可能来自两处——已存记录或编译期默认值，所以这里只需区分默认值的两种成因。"""


    STORED = 0
    DEFAULT_NO_RECORD = 1
    DEFAULT_STORAGE_UNAVAILABLE = 2

# effect_id 取值。0 保留给『恢复正常/由 MCU 自主决定』。安全模式 / FAULT 期间的灯效由 MCU 自主决定，本命令不可覆盖。6/7/8 为 revision 2.0 追加（任务层按任务换动画需要更多动画名）；0–5 的取值与含义不变。`RAINBOW(5)` **已退休**：产品不需要彩虹灯，固件按集合判合法时未实现它、下发回 UNSUPPORTED（值 5 保留、不复用）。
class Led_effect(enum.IntEnum):
    """effect_id 取值。0 保留给『恢复正常/由 MCU 自主决定』。安全模式 / FAULT 期间的灯效由 MCU 自主决定，本命令不可覆盖。6/7/8 为 revision 2.0 追加（任务层按任务换动画需要更多动画名）；0–5 的取值与含义不变。`RAINBOW(5)` **已退休**：产品不需要彩虹灯，固件按集合判合法时未实现它、下发回 UNSUPPORTED（值 5 保留、不复用）。"""


    AUTO = 0
    SOLID = 1
    BREATHE = 2
    BLINK = 3
    CHASE = 4
    RAINBOW = 5
    COMET_DUAL = 6
    TIDE = 7
    RIPPLE = 8

# 数组下标语义。第 7 路为夹爪，不是第 8 个旋转关节。夹爪是可选配件——MCU 在每次使能（DISABLED→HOLD）时探测其是否物理在线；探测结论用于准入/限位/故障聚合。TELEMETRY per-motor status 的 bit3（installed）是呈现口径的『在位』：探测结论为已安装，或该路本帧有新鲜反馈——未使能时也会随总线应答变化，不要误读成运行中重新探测。未安装时第 7 路不参与限位校验、不参与故障聚合、fault_code 不含其状态；已安装时第 7 路的故障只置位它自己的 status bit1，不影响 0..6 路的运行，也不把顶层 execution_state 推入 FAULT——即『只锁夹爪，手臂仍可继续被命令』。运行中（RUNNING）不重新探测，准入侧的安装状态只在使能时刷新一次；不支持 RUNNING 中的热插拔识别。
class Joint_index(enum.IntEnum):
    """数组下标语义。第 7 路为夹爪，不是第 8 个旋转关节。夹爪是可选配件——MCU 在每次使能（DISABLED→HOLD）时探测其是否物理在线；探测结论用于准入/限位/故障聚合。TELEMETRY per-motor status 的 bit3（installed）是呈现口径的『在位』：探测结论为已安装，或该路本帧有新鲜反馈——未使能时也会随总线应答变化，不要误读成运行中重新探测。未安装时第 7 路不参与限位校验、不参与故障聚合、fault_code 不含其状态；已安装时第 7 路的故障只置位它自己的 status bit1，不影响 0..6 路的运行，也不把顶层 execution_state 推入 FAULT——即『只锁夹爪，手臂仍可继续被命令』。运行中（RUNNING）不重新探测，准入侧的安装状态只在使能时刷新一次；不支持 RUNNING 中的热插拔识别。"""


    J0 = 0
    J1 = 1
    J2 = 2
    J3 = 3
    J4 = 4
    J5 = 5
    J6 = 6
    GRIPPER = 7

# 板载数据存储（revision 2.6）的记录类型。`index` 语义随类型：TEACH_SLOT 0..7（8 个示教槽），PAYLOAD / DEVICE_CONFIG 恒 0。固件**不解析**记录内容，只做块存取 + CRC32 + 双槽提交。
class Storage_record_type(enum.IntEnum):
    """板载数据存储（revision 2.6）的记录类型。`index` 语义随类型：TEACH_SLOT 0..7（8 个示教槽），PAYLOAD / DEVICE_CONFIG 恒 0。固件**不解析**记录内容，只做块存取 + CRC32 + 双槽提交。"""


    TEACH_SLOT = 2
    PAYLOAD = 3
    DEVICE_CONFIG = 4


# 消息长度与字段偏移
SIZES: dict[str, dict[str, int]] = {
    "HELLO": {
        "request": 1,
        "response": 12,
    },
    "ACQUIRE": {
        "request": 4,
        "response": 8,
    },
    "RENEW": {
        "request": 4,
        "response": 8,
    },
    "RELEASE": {
        "request": 0,
        "response": 1,
    },
    "MIT_CMD": {
        "request": 160,
        "response": 4,
    },
    "TELEMETRY": {
        "response": 168,
    },
    "SET_LED_EFFECT": {
        "request": 9,
        "response": 1,
    },
    "FAULT_RESET": {
        "request": 0,
        "response": 1,
    },
    "SET_ENABLE": {
        "request": 1,
        "response": 1,
    },
    "DEVICE_INFO": {
        "request": 0,
        "response": 104,
    },
    "ENTER_BOOTLOADER": {
        "request": 5,
        "response": 1,
    },
    "SET_NET_CONFIG": {
        "request": 16,
        "response": 1,
    },
    "GET_NET_CONFIG": {
        "request": 0,
        "response": 36,
    },
    "STORAGE_BEGIN": {
        "request": 8,
        "response": 1,
    },
    "STORAGE_WRITE_CHUNK": {
        "request": 132,
        "response": 1,
    },
    "STORAGE_COMMIT": {
        "request": 12,
        "response": 1,
    },
    "STORAGE_READ_CHUNK": {
        "request": 5,
        "response": 129,
    },
    "STORAGE_INFO": {
        "request": 2,
        "response": 13,
    },
}

OFFSETS: dict[str, dict[str, dict[str, int]]] = {
    "HELLO": {
        "request": {
            "client_protocol_major": 0,
        },
        "response": {
            "protocol_major": 0,
            "protocol_minor": 1,
            "motor_count": 2,
            "reserved": 3,
            "capability_flags": 4,
            "max_lease_us": 8,
        },
    },
    "ACQUIRE": {
        "request": {
            "requested_lease_us": 0,
        },
        "response": {
            "result": 0,
            "reserved": 1,
            "reserved2": 2,
            "granted_lease_us": 4,
        },
    },
    "RENEW": {
        "request": {
            "requested_lease_us": 0,
        },
        "response": {
            "result": 0,
            "reserved": 1,
            "reserved2": 2,
            "granted_lease_us": 4,
        },
    },
    "RELEASE": {
        "request": {
        },
        "response": {
            "result": 0,
        },
    },
    "MIT_CMD": {
        "request": {
            "_element_size": 20,
            "_count": 8,
            "q_des": 0,
            "dq_des": 4,
            "kp": 8,
            "kd": 12,
            "tau_ff": 16,
        },
        "response": {
            "result": 0,
            "reason": 1,
            "reserved": 2,
        },
    },
    "TELEMETRY": {
        "response": {
            "execution_state": 0,
            "stop_reason": 1,
            "fault_code": 2,
            "reserved": 3,
            "last_rx_sequence": 4,
            "_tail_offset": 8,
            "_tail_count": 8,
            "_tail_element_size": 20,
            "tail.q": 0,
            "tail.dq": 4,
            "tail.tau_est": 8,
            "tail.status": 12,
            "tail.temp": 13,
            "tail.voltage": 14,
            "tail.temp2": 15,
            "tail.error_mask": 16,
            "tail.reserved2": 18,
        },
    },
    "SET_LED_EFFECT": {
        "request": {
            "effect_id": 0,
            "color_primary_rgb": 1,
            "color_secondary_rgb": 4,
            "period_ms": 7,
        },
        "response": {
            "result": 0,
        },
    },
    "FAULT_RESET": {
        "request": {
        },
        "response": {
            "result": 0,
        },
    },
    "SET_ENABLE": {
        "request": {
            "enable": 0,
        },
        "response": {
            "result": 0,
        },
    },
    "DEVICE_INFO": {
        "request": {
        },
        "response": {
            "motor_count": 0,
            "joint_count": 1,
            "reserved": 2,
            "geometry_id": 4,
            "calibration_version": 8,
            "sw_major": 10,
            "sw_minor": 11,
            "bootloader_major": 12,
            "bootloader_minor": 13,
            "bootloader_rev": 14,
            "sw_rev": 15,
            "_tail_offset": 16,
            "_tail_count": 8,
            "_tail_element_size": 11,
            "tail.lower": 0,
            "tail.upper": 4,
            "tail.axis_x": 8,
            "tail.axis_y": 9,
            "tail.axis_z": 10,
        },
    },
    "ENTER_BOOTLOADER": {
        "request": {
            "magic": 0,
            "reason": 4,
        },
        "response": {
            "result": 0,
        },
    },
    "SET_NET_CONFIG": {
        "request": {
            "ip": 0,
            "mask": 4,
            "gateway": 8,
            "server_port": 12,
            "broadcast_port": 14,
        },
        "response": {
            "result": 0,
        },
    },
    "GET_NET_CONFIG": {
        "request": {
        },
        "response": {
            "running_ip": 0,
            "running_mask": 4,
            "running_gateway": 8,
            "running_server_port": 12,
            "running_broadcast_port": 14,
            "saved_ip": 16,
            "saved_mask": 20,
            "saved_gateway": 24,
            "saved_server_port": 28,
            "saved_broadcast_port": 30,
            "status": 32,
            "flags": 33,
            "reserved": 34,
        },
    },
    "STORAGE_BEGIN": {
        "request": {
            "record_type": 0,
            "record_index": 1,
            "reserved": 2,
            "total_len": 4,
        },
        "response": {
            "result": 0,
        },
    },
    "STORAGE_WRITE_CHUNK": {
        "request": {
            "record_type": 0,
            "index": 1,
            "offset": 2,
            "data": 4,
        },
        "response": {
            "result": 0,
        },
    },
    "STORAGE_COMMIT": {
        "request": {
            "record_type": 0,
            "index": 1,
            "reserved": 2,
            "total_len": 4,
            "crc32": 8,
        },
        "response": {
            "result": 0,
        },
    },
    "STORAGE_READ_CHUNK": {
        "request": {
            "record_type": 0,
            "index": 1,
            "offset": 2,
            "len": 4,
        },
        "response": {
            "result": 0,
            "data": 1,
        },
    },
    "STORAGE_INFO": {
        "request": {
            "record_type": 0,
            "index": 1,
        },
        "response": {
            "result": 0,
            "record_size": 1,
            "generation": 5,
            "crc32": 9,
        },
    },
}


def header_struct() -> struct.Struct:
    """通用头部的打包/解包器（不含 payload 与 CRC）。"""
    return struct.Struct(BYTE_ORDER + "BBHHHII")
