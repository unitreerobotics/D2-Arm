"""D2 Arm SDK stable V1 customer API.

Implementation modules remain importable for internal integrations, but only
names listed here are supported as root-level imports.
"""

from __future__ import annotations

from .device.device import Device, DeviceConfig, LinkError, ProtocolVersionError, SessionError
from .device.session import SessionInfo
from .device.snapshot import MotorState, TelemetrySnapshot
from .runtime.runtime import ArmRuntime
from .api import (
    ApplyPayloadResult,
    ClearPayloadResult,
    Mode,
    MotionController,
    MotionHandle,
    MotionResult,
    MotionStatus,
    PayloadIdentificationService,
    PayloadState,
    PayloadSubmitResult,
)
from .runtime.identification import IdentificationConfig, IdentificationError
from .motion.payload import PayloadParameters
from .motion.gripper import GripperCalibration, GripperError
from .runtime.servoj import ServoJError
from .payload_store import PayloadStore, PayloadStoreError, SaveResult, SavedPayload
from .teach_store import TeachStore, TeachStoreError
# 板载数据存储。**不进根 __all__**：内部接线用，用户经 ``arm.device_data`` /
# ``arm.device_config``（facade 便捷入口）；需要底层访问可直接
# `from arm_sdk.storage import ...`。
from .storage import DeviceStorage, DeviceStorageError, StorageRecord
from .upgrade import (
    FirmwareUpgrade,
    PreflightError,
    UpgradeAborted,
    UpgradeError,
    UpgradeProgress,
    UpgradeResult,
    UpgradeTransferError,
    VerificationError,
    upgrade_firmware,
)
# 便捷入口（facade，纯 Python，最后导入：避免与上面各子模块的重入顺序纠缠）。
from .facade import Arm, EnableError, connect

__all__ = [
    "connect",
    "Arm",
    "EnableError",
    "Device",
    "DeviceConfig",
    "LinkError",
    "ProtocolVersionError",
    "SessionError",
    "SessionInfo",
    "TelemetrySnapshot",
    "MotorState",
    "ArmRuntime",
    "MotionController",
    "MotionHandle",
    "MotionResult",
    "MotionStatus",
    "Mode",
    "IdentificationConfig",
    "IdentificationError",
    "PayloadIdentificationService",
    "PayloadState",
    "ApplyPayloadResult",
    "ClearPayloadResult",
    "PayloadSubmitResult",
    "PayloadParameters",
    "PayloadStore",
    "PayloadStoreError",
    "SavedPayload",
    "SaveResult",
    "TeachStore",
    "TeachStoreError",
    "GripperCalibration",
    "GripperError",
    "ServoJError",
    "FirmwareUpgrade",
    "upgrade_firmware",
    "UpgradeError",
    "PreflightError",
    "UpgradeTransferError",
    "UpgradeAborted",
    "VerificationError",
    "UpgradeProgress",
    "UpgradeResult",
]
