"""Runtime 层：连接/会话/遥测消费线程/发 MIT 的小 runtime（无规划）。"""

from __future__ import annotations

from .mit import (
    DEFAULT_KP_KD,
    CommandError,
    MitStreamer,
    StreamerStats,
    build_hold_command,
    build_target_command,
    validate_mit,
)
from .drag import (
    DEFAULT_DRAG_KD,
    MAX_DRAG_KD,
    MIN_DRAG_KD,
    DragSupplier,
    clamp_drag_kd,
)
from .passive import DAMPING_KD, ZERO_TORQUE_KD, PassiveSupplier
from .fatigue import (
    DEFAULT_SPEED_SCALE,
    FATIGUE_ACCEL_DEG_S2,
    FATIGUE_HOME_TIMEOUT_S,
    FATIGUE_SCAN_DEG,
    FATIGUE_SPEED_DEG_S,
    SPEED_SCALE_MAX,
    SPEED_SCALE_MIN,
    FatigueSupplier,
    clamp_speed_scale,
)
from .runtime import ArmRuntime
from .trajectory import DEFAULT_SPEED, TrajectorySupplier

__all__ = [
    "ArmRuntime",
    "MitStreamer",
    "StreamerStats",
    "DEFAULT_KP_KD",
    "CommandError",
    "build_hold_command",
    "build_target_command",
    "validate_mit",
    "TrajectorySupplier",
    "DEFAULT_SPEED",
    "DragSupplier",
    "clamp_drag_kd",
    "DEFAULT_DRAG_KD",
    "MIN_DRAG_KD",
    "MAX_DRAG_KD",
    "PassiveSupplier",
    "DAMPING_KD",
    "ZERO_TORQUE_KD",
    "FatigueSupplier",
    "clamp_speed_scale",
    "FATIGUE_SCAN_DEG",
    "FATIGUE_SPEED_DEG_S",
    "FATIGUE_ACCEL_DEG_S2",
    "FATIGUE_HOME_TIMEOUT_S",
    "SPEED_SCALE_MIN",
    "SPEED_SCALE_MAX",
    "DEFAULT_SPEED_SCALE",
]
