"""arm_sdk 便捷入口（facade）：``connect`` / ``Arm`` —— 最小 10 行跑通。

    import arm_sdk
    with arm_sdk.connect("udp://192.168.123.2:2000") as arm:
        arm.enable()
        arm.motion.movej([0, 0.3, 0, -0.5, 0, 0, 0], speed=1.0).wait()
    # 退出：自动 disable（若已 enable）→ release/close

行为约定：
- ``connect`` 只建链+取控制权，**不自动使能**，客户显式 ``arm.enable()``；
- ``with`` 退出自动失能 + 断链，best-effort，绝不掩盖 with 体内主异常；
- ``close`` 幂等，可重复调用；
- 本模块只做纯 Python 薄委托，底层 API（``Device`` / ``ArmRuntime`` / ``MotionController``）不变。

线程模型：一把 ``RLock`` 串行化**一切会触达设备的入口**（写命令，以及可能发设备
往返的只读查询：首次 ``gripper.state()``、``robot.device_info()``、``device_config`` /
``device_data`` 与 ``payloads`` 的变更类、以及长操作 ``upgrade.run``），
避免用户命令与续租/遥测线程、或两条用户命令互相打断。

**不持主锁的**只有纯内存只读：``state.snapshot()/joints()/wait_state()/wait_idle()``
与 ``enabled``（仅读最新快照，等待期间不阻塞命令）。遥测分发走独立 ``_sub_lock``（不碰主锁，
无锁序倒置）。
"""

from __future__ import annotations

import base64
import json
import os
import struct
import threading
import time
import urllib.parse
from datetime import datetime, timezone

from .api.identification import PayloadIdentificationService
from .api.motion import MotionController, MotionHandle, MotionStatus
from .device.device import (
    Device,
    LinkError,
    ProtocolVersionError,
    SessionError,
)
from .motion.gripper import GripperCalibration
from .motion.mounting import normalize_mounting
from .payload_store import PayloadStore
from .protocol.constants import JOINT_COUNT, P
from .runtime.gravity import GravityError
from .runtime.runtime import ArmRuntime
from .storage import DeviceStorage, DeviceStorageError, StorageRecord
from .teach_store import MAX_WAYPOINTS, SLOT_COUNT, TeachStore, TeachStoreError
from .transport.base import TransportError
from .upgrade import upgrade_firmware

#: 使能确认轮询间隔（秒）——与后端 ``_ENABLE_CONFIRM_POLL_S`` 同口径。
_ENABLE_CONFIRM_POLL_S = 0.005
#: 使能 / 失能确认默认上限（秒）。``set_enable`` 是异步的，返回 OK 只表示设备受理。
DEFAULT_ENABLE_TIMEOUT_S = 0.5
#: ``arm.state`` 轮询间隔（秒）。
_STATE_POLL_S = 0.005

#: 已使能判据用的执行状态（revision 2.0）：HOLD(1) / RUNNING(2) 都意味着"电机有力"。
_ENABLED_STATES = (int(P.Execution_state.HOLD), int(P.Execution_state.RUNNING))

#: 结果码 → 中文建议动作（异常文案 = 码名 + 建议；**唯一**一份）。
_RESULT_SUGGESTIONS = {
    int(P.Result.DENIED_BUSY): "控制权被占用：请确认其他客户端已释放",
    int(P.Result.NOT_READY): "设备未就绪：请稍后重试",
    int(P.Result.BAD_BOOT): "设备已复位（boot_id 不符）：请重新连接",
    int(P.Result.BAD_SESSION): "会话已失效：请重新获取控制权",
    int(P.Result.FAULT_ACTIVE): "存在故障：请先执行 fault_reset",
    int(P.Result.OUT_OF_RANGE): "参数越界：请检查取值范围",
    int(P.Result.INTERNAL_ERROR): "设备内部错误：请重试或联系供货方",
    int(P.Result.UNSUPPORTED): "设备不支持该操作：请确认固件版本",
}


class EnableError(RuntimeError):
    """使能 / 失能未能确认（设备显式拒绝，或遥测未在时限内确认状态）。

    底层异常类型（``SessionError`` / ``LinkError`` / ``TransportError``）**原样穿透**；
    只有"设备受理了但没有变成目标状态 / 设备显式拒绝"才抛本异常。

    只读字段（便于程序化处理，而非只解析消息串）：
    - :attr:`result`：设备显式拒绝时的结果码（``int``，如 ``DENIED_BUSY``）；超时未确认时为 ``None``。
    - :attr:`observed`：超时时的最后观测描述（``str``）；设备显式拒绝时为 ``None``。
    """

    def __init__(self, message: str, *, result: int | None = None, observed: str | None = None) -> None:
        super().__init__(message)
        self.result = result
        self.observed = observed


def _result_name(code) -> str:
    try:
        return P.Result(int(code)).name
    except (ValueError, TypeError):
        return f"UNKNOWN_{code}"


def _readable_result(code) -> str:
    """结果码 → ``NAME(n)：建议``（可读异常文案的唯一组装点）。"""
    value = int(code)
    text = f"{_result_name(value)}({value})"
    tip = _RESULT_SUGGESTIONS.get(value)
    return f"{text}：{tip}" if tip else text


def _exec_state_name(value) -> str:
    try:
        return P.Execution_state(int(value)).name
    except (ValueError, TypeError):
        return f"UNKNOWN_{value}"


def _parse_target(target: str) -> tuple[str, str, int]:
    """把连接目标字符串解析为 ``(kind, host_or_path, port_or_baud)``。

    支持 ``udp://host:port`` 与 ``serial://<设备路径>``（串口建议用 by-id 稳定路径，
    可附加 ``?baud=115200`` 覆盖默认波特率）。
    """
    if not isinstance(target, str) or not target:
        raise ValueError(
            f"连接目标需为非空字符串（udp://host:port 或 serial://<设备路径>），得到 {target!r}"
        )
    if target.startswith("udp://"):
        rest = target[len("udp://"):]
        host, sep, port = rest.rpartition(":")
        if not sep or not host or not port.isdigit():
            raise ValueError(f"udp 目标需形如 udp://host:port，得到 {target!r}")
        return ("udp", host, int(port))
    if target.startswith("serial://"):
        rest = target[len("serial://"):]
        path, _, query = rest.partition("?")
        path = urllib.parse.unquote(path)
        if not path:
            raise ValueError(f"serial 目标缺少设备路径，得到 {target!r}")
        baud = 5_000_000
        for item in query.split("&"):
            key, _, value = item.partition("=")
            if key == "baud" and value:
                try:
                    baud = int(value)
                except ValueError as exc:
                    raise ValueError(f"serial baud 非法：{value!r}") from exc
        return ("serial", path, baud)
    raise ValueError(
        f"无法识别的连接目标 {target!r}（支持 udp://host:port 与 serial://<设备路径>）"
    )


def _build_device(
    target: str,
    *,
    lease_us: int,
    renew_interval_s: float,
    request_timeout_s: float,
    telemetry_stale_s: float,
    auto_reacquire: bool,
) -> Device:
    kind, host_or_path, port_or_baud = _parse_target(target)
    common = dict(
        lease_us=lease_us,
        renew_interval_s=renew_interval_s,
        request_timeout_s=request_timeout_s,
        telemetry_stale_s=telemetry_stale_s,
        auto_reacquire=auto_reacquire,
    )
    if kind == "udp":
        return Device.udp(host_or_path, port_or_baud, **common)
    return Device.serial(host_or_path, baud=port_or_baud, **common)


def _read_device_config(storage: DeviceStorage) -> dict | None:
    """读板上 DEVICE_CONFIG 记录（JSON ``{mounting, name}``）；无记录 / 不可读返回 ``None``。

    建链期的 best-effort 读取——设备配置属可选信息，读不到（旧固件 / 临时链路抖动）不得
    阻断连接：此时按连接的 ``mounting=`` 入参取值。
    """
    try:
        if storage.info_record(StorageRecord.DEVICE_CONFIG) is None:
            return None
        raw = storage.read_record(StorageRecord.DEVICE_CONFIG)
        obj = json.loads(raw.decode("utf-8"))
    except Exception:  # noqa: BLE001 — 可选信息，读不到不阻断建链
        return None
    return obj if isinstance(obj, dict) else None


def _resolve_mounting(storage: DeviceStorage, default: str) -> str:
    """建链安装方式：**板上 DEVICE_CONFIG 有记录则权威**，否则用 ``default``。

    这里**只取初值、不写板**（连接期不做写板，避免副作用；且无记录时属正常默认路径）。
    用户经 ``arm.device_config.mounting = ...`` 落板后，后续连接以板上值为准。
    """
    cfg = _read_device_config(storage)
    if cfg is not None:
        stored = cfg.get("mounting")
        if isinstance(stored, str) and stored:
            return stored
    return default


def _build_stores(storage: DeviceStorage, teach_store, payload_store):
    """把 teach / payload 存储注入规整：显式路径 → 文件后端；未给 → 默认**板载**后端。

    ``teach_store=`` / ``payload_store=`` 是**测试注入口**（文件后端，或传入已构造的 store）；
    生产默认（都不传）走 ``DeviceStorage``，数据随臂走。
    """
    if isinstance(teach_store, (str, os.PathLike)):
        teach_store = TeachStore(os.fspath(teach_store))
    elif teach_store is None:
        teach_store = TeachStore(board=storage)
    if isinstance(payload_store, (str, os.PathLike)):
        payload_store = PayloadStore(os.fspath(payload_store), create=True)
    elif payload_store is None:
        payload_store = PayloadStore(board=storage)
    return teach_store, payload_store


def _hello_readable(device: Device):
    """HELLO 并复用统一的可读包装（协议主版本不符 ⇒ 提示联系供货方）。

    ``connect`` 与 ``Arm.reconnect`` 共用，避免两处文案漂移。
    """
    try:
        return device.hello()
    except ProtocolVersionError as exc:
        raise ProtocolVersionError(
            f"{exc}；请升级 SDK/上位机到与设备匹配的协议版本，或联系供货方"
        ) from exc


def connect(
    target: str,
    *,
    mounting: str = "upright",
    rate_hz: float = 500.0,
    lease_us: int = 1_000_000,
    request_timeout_s: float = 0.3,
    telemetry_stale_s: float = 0.5,
    renew_interval_s: float = 0.5,
    fresh_s: float | None = None,
    auto_reacquire: bool = True,
    kp_kd=None,
    gripper_calibration: GripperCalibration | None = None,
    teach_store: TeachStore | str | None = None,
    payload_store: PayloadStore | str | None = None,
    bootloader_ip: str | None = None,
    bootloader_port: int | None = None,
) -> "Arm":
    """建立到机械臂的高层连接并返回 :class:`Arm`（**不自动使能**）。

    内部流程：``Device.udp/serial`` → ``open()`` → ``hello()`` → ``acquire()`` →
    ``ArmRuntime`` → ``MotionController``（自动挂重力/夹爪/辨识，见 ``api/motion.py``）。
    ``auto_reacquire=True``（默认）⇒ 链路闪断时底层自动重取控制权。

    **存储默认板载**：示教槽与单套负载自动走设备板载记录（``DeviceStorage``），
    数据随臂走。``teach_store=`` / ``payload_store=`` 是**测试注入口**（给路径走文件后端，
    或直接传已构造的 store）；不传即板载。

    **安装方式优先级**：``mounting=`` 只做**板上无 DEVICE_CONFIG 记录时的初值**；一旦板上
    有记录，**板上权威**（见 :class:`_DeviceConfigNamespace`）。连接期只读板、不写板。

    ``hello`` 校验协议主版本，不匹配抛可读的 :class:`ProtocolVersionError`（提示联系供货方）。
    **任一步失败：先 ``close()`` 再抛**，绝不留半开链路。
    """
    device = _build_device(
        target,
        lease_us=lease_us,
        renew_interval_s=renew_interval_s,
        request_timeout_s=request_timeout_s,
        telemetry_stale_s=telemetry_stale_s,
        auto_reacquire=auto_reacquire,
    )
    try:
        device.open()
        _hello_readable(device)
        device.acquire()

        # acquire 成功即已占控制权（续租线程在跑）；此后**任一建构步骤**抛异常都必须先
        # close 再抛，否则会留下已 open 的 device（持续续租、占用控制权）。
        runtime_kwargs = {
            "rate_hz": rate_hz,
            "fresh_s": telemetry_stale_s if fresh_s is None else fresh_s,
        }
        if kp_kd is not None:
            runtime_kwargs["kp_kd"] = kp_kd
        runtime = ArmRuntime(device, **runtime_kwargs)

        # 板载存储接线：板上 DEVICE_CONFIG 有记录则安装方式权威=板上。
        # 存储写只要求持有会话，不再要求客户端失能态。
        storage = DeviceStorage(device)
        mounting = _resolve_mounting(storage, mounting)

        controller = MotionController(runtime, mounting=mounting)
        if gripper_calibration is not None:
            controller.configure_gripper(gripper_calibration)

        teach_store, payload_store = _build_stores(storage, teach_store, payload_store)
        return Arm(
            device,
            runtime,
            controller,
            target=target,
            mounting=mounting,
            teach_store=teach_store,
            payload_store=payload_store,
            storage=storage,
            bootloader_ip=bootloader_ip,
            bootloader_port=bootloader_port,
        )
    except BaseException:
        # 任一步失败：先关链路，再把原异常抛出（不吞不包）。
        try:
            device.close()
        except Exception:  # noqa: BLE001 — 收尾失败不得掩盖建链主异常
            pass
        raise


class _RobotNamespace:
    """``arm.robot``：链路 / 会话级只读视图与少量命令（薄委托）。"""

    def __init__(self, owner: "Arm") -> None:
        self._owner = owner

    @property
    def held(self) -> bool:
        return self._owner._device.held

    @property
    def link_ok(self) -> bool:
        return self._owner._device.link_ok

    @property
    def boot_id(self) -> int:
        return self._owner._device.boot_id

    @property
    def storage(self) -> DeviceStorage:
        """低层板载存储入口（进阶）：owner 已持有的 :class:`DeviceStorage` 实例（同一对象）。"""
        return self._owner._storage

    def device_info(self, timeout: float | None = None):
        with self._owner._lock:
            return self._owner._device.device_info(timeout)

    def fault_reset(self, timeout: float | None = None):
        with self._owner._lock:
            return self._owner._runtime.fault_reset()

    def reconnect(self) -> "Arm":
        return self._owner.reconnect()

    def close(self) -> None:
        self._owner.close()


class _StateNamespace:
    """``arm.state``：遥测只读视图 + 订阅（回调在遥测线程内联调用，**勿阻塞**）。"""

    def __init__(self, owner: "Arm") -> None:
        self._owner = owner

    def snapshot(self):
        """最新 :class:`TelemetrySnapshot`；尚无遥测返回 ``None``。"""
        return self._owner._device.telemetry()

    def joints(self) -> list[float] | None:
        """前 7 个关节的实测 ``q``（rad，URDF 系）；无遥测返回 ``None``。"""
        snap = self.snapshot()
        if snap is None or len(snap.motors) < JOINT_COUNT:
            return None
        return [snap.motors[i].q for i in range(JOINT_COUNT)]

    def wait_state(self, pred, timeout: float | None = None):
        """轮询直到 ``pred(snapshot)`` 为真；返回命中的快照，超时返回 ``None``。

        仅对**非 None** 的快照调用 ``pred``。
        """
        deadline = None if timeout is None else time.monotonic() + float(timeout)
        while True:
            snap = self.snapshot()
            if snap is not None and pred(snap):
                return snap
            if deadline is not None and time.monotonic() >= deadline:
                return None
            time.sleep(_STATE_POLL_S)

    def subscribe(self, callback) -> None:
        """登记遥测回调；同一回调重复登记只算一次。

        ⚠️ 回调**在遥测线程内联调用**（500 Hz 量级），**回调内勿阻塞**（禁止网络/磁盘/长计算）。
        回调抛出的异常被忽略并计数（见 :attr:`callback_errors`），**不会打断遥测流**。
        """
        self._owner._subscribe(callback)

    def unsubscribe(self, callback) -> None:
        self._owner._unsubscribe(callback)

    @property
    def callback_errors(self) -> int:
        """累计被吞掉的遥测回调异常数。"""
        return self._owner._callback_errors


class _MotionNamespace:
    """``arm.motion``：薄委托 ``MotionController``，并跟踪句柄供 :meth:`Arm.stop`。"""

    def __init__(self, owner: "Arm") -> None:
        self._owner = owner

    def _call(self, method: str, *args, **kwargs):
        with self._owner._lock:
            return self._owner._track(getattr(self._owner._controller, method)(*args, **kwargs))

    def movej(self, q, speed: float | None = None, accel: float | None = None) -> MotionHandle:
        return self._call("movej", q, speed, accel)

    def movejp(self, pos, rpy, speed: float | None = None, accel: float | None = None) -> MotionHandle:
        return self._call("movejp", pos, rpy, speed, accel)

    def home(self, speed: float | None = None, accel: float | None = None) -> MotionHandle:
        return self._call("home", speed, accel)

    def servoj_start(self) -> MotionHandle:
        return self._call("servoj_start")

    def servoj(self, q, t) -> None:
        with self._owner._lock:
            self._owner._controller.servoj(q, t)

    def servoj_end(self) -> bool:
        with self._owner._lock:
            return self._owner._controller.servoj_end()

    def start_drag(self, kd: float | None = None) -> MotionHandle:
        if kd is None:
            return self._call("start_drag")
        return self._call("start_drag", kd)

    def start_damping(self) -> MotionHandle:
        return self._call("start_damping")

    def start_zero_torque(self) -> MotionHandle:
        return self._call("start_zero_torque")

    def start_fatigue(self, rounds=None, speed_scale: float = 1.0) -> MotionHandle:
        return self._call("start_fatigue", rounds, speed_scale)

    def fatigue_state(self) -> dict | None:
        """疲劳测试进度（``{"rounds_done", "rounds_target", "phase", "stop_reason"}``；未在跑返回 ``None``）。"""
        with self._owner._lock:
            return self._owner._controller.fatigue_state()

    def identify(self, config, *, sample_only: bool = False) -> MotionHandle:
        return self._call("identify", config, sample_only=sample_only)

    def wait_idle(self, timeout: float | None = None) -> bool:
        """等遥测 ``execution_state`` 离开 RUNNING；超时返回 ``False``。"""
        deadline = None if timeout is None else time.monotonic() + float(timeout)
        while True:
            snap = self._owner._device.telemetry()
            if snap is not None and int(snap.execution_state) != int(P.Execution_state.RUNNING):
                return True
            if deadline is not None and time.monotonic() >= deadline:
                return False
            time.sleep(_STATE_POLL_S)


class _GripperNamespace:
    """``arm.gripper``：转发给 ``MotionController.gripper``（dict 返回语义不变）。"""

    def __init__(self, owner: "Arm") -> None:
        self._owner = owner

    def move(self, percent, speed=None, hold_torque=None) -> dict:
        with self._owner._lock:
            return self._owner._controller.gripper.move(percent, speed, hold_torque)

    def open(self, speed=None, hold_torque=None) -> dict:
        with self._owner._lock:
            return self._owner._controller.gripper.open(speed, hold_torque)

    def close(self, speed=None, hold_torque=None) -> dict:
        with self._owner._lock:
            return self._owner._controller.gripper.close(speed, hold_torque)

    def stop(self) -> dict:
        with self._owner._lock:
            return self._owner._controller.gripper.stop()

    def state(self) -> dict:
        # 首次（量程未缓存）会经 _refresh → device.device_info() 发设备往返 ⇒ 须持主锁。
        with self._owner._lock:
            return self._owner._controller.gripper.state()

    def configure(self, calibration: GripperCalibration) -> None:
        with self._owner._lock:
            self._owner._controller.configure_gripper(calibration)


class _TeachNamespace:
    """``arm.teach``：委托 ``MotionController.teach*`` 与可选 ``TeachStore``（槽位持久化）。"""

    def __init__(self, owner: "Arm", store: TeachStore | None) -> None:
        self._owner = owner
        self._store = store

    @property
    def store(self) -> TeachStore | None:
        return self._store

    @property
    def waypoints(self):
        return self._owner._controller.teach.waypoints

    def record(self) -> dict:
        with self._owner._lock:
            return self._owner._controller.teach_record()

    def delete_last(self) -> dict:
        with self._owner._lock:
            return self._owner._controller.teach_delete_last()

    def play(self, speed=None, accel=None, loop: bool = False) -> MotionHandle:
        with self._owner._lock:
            return self._owner._track(self._owner._controller.teach_play(speed, accel, loop))

    def state(self) -> dict:
        return self._owner._controller.teach_state()

    def set_speed(self, speed) -> float:
        return self._owner._controller.teach_set_speed(speed)

    def set_accel(self, accel):
        return self._owner._controller.teach_set_accel(accel)

    def set_loop(self, loop) -> bool:
        return self._owner._controller.teach_set_loop(loop)

    def _require_store(self) -> TeachStore:
        if self._store is None:
            raise TeachStoreError("未配置示教槽位存储（connect 默认板载；测试可传 teach_store=）")
        return self._store

    def save(self, slot) -> list[list[float]]:
        """把当前工作轨迹存入槽位（成功后标记当前槽与"已保存"）。"""
        saved = self._require_store().save_slot(slot, [list(wp) for wp in self.waypoints])
        self._owner._controller.teach.mark_saved(slot)
        return saved

    def load(self, slot) -> list[list[float]]:
        """从槽位读入工作轨迹。"""
        waypoints = self._require_store().load_slot(slot)
        self._owner._controller.teach.load(waypoints, slot=slot)
        return waypoints

    def clear(self, slot) -> None:
        self._require_store().clear_slot(slot)
        self._owner._controller.teach.on_slot_cleared(slot)

    def list_slots(self) -> list[bool]:
        return self._require_store().list_slots()


class _PayloadsNamespace:
    """``arm.payloads``：委托 ``PayloadIdentificationService``（辨识 / 状态 / 清除 / 应用）。"""

    def __init__(self, owner: "Arm") -> None:
        self._owner = owner
        self._service = PayloadIdentificationService(owner._controller, store=owner._payload_store)

    @property
    def service(self) -> PayloadIdentificationService:
        return self._service

    @property
    def store(self):
        return self._service.store

    def default_config(self):
        """冻结的生产辨识预设（与上位机同一套；值见 ``IdentificationConfig.production()``）。"""
        from .runtime.identification import IdentificationConfig

        return IdentificationConfig.production()

    def identify(self, config):
        with self._owner._lock:
            return self._owner._track(self._service.identify_payload(config))

    def identify_bidirectional(self, config, *, max_batch_poses: int = 16, progress_cb=None):
        with self._owner._lock:
            return self._owner._track(
                self._service.identify_payload_bidirectional(
                    config, max_batch_poses=max_batch_poses, progress_cb=progress_cb
                )
            )

    def state(self, *, include_saved: bool = True):
        with self._owner._lock:
            return self._service.payload_state(include_saved=include_saved)

    def cancel(self) -> bool:
        with self._owner._lock:
            return self._service.cancel_payload_identification()

    def clear(self):
        with self._owner._lock:
            return self._service.clear_payload()

    def apply_saved(self):
        with self._owner._lock:
            return self._service.apply_saved_payload()


#: 板载数据整机备份束 schema（单个 JSON 对象，**不是 zip**）。
DATA_SCHEMA = "d2arm.device-data.v1"

#: 示教槽板载记录：新版**变长**（count u16 LE + count×7×f32，4B 对齐）；旧版写满定长。
_TEACH_RECORD_BYTES = 2 + MAX_WAYPOINTS * JOINT_COUNT * 4

#: 缓存中已用槽判据用的默认关节数（与 teach_store 一致）。
_TEACH_ELEM = JOINT_COUNT * 4


def _align4(n: int) -> int:
    return n + (-n) % 4


def _teach_record_valid(raw: bytes) -> bool:
    """板载示教记录结构合法性：旧定长（7170/7172）或新变长（align4(2+count×28)）皆可。"""
    n = len(raw)
    if n < 2:
        return False
    if n in (_TEACH_RECORD_BYTES, _align4(_TEACH_RECORD_BYTES)):
        return True  # 旧定长（含 4B 对齐后的 7172）
    count = int.from_bytes(raw[:2], "little")
    if count <= 0 or count > MAX_WAYPOINTS:
        return False
    return n == _align4(2 + count * _TEACH_ELEM)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json_bytes(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False).encode("utf-8")


class _DeviceConfigNamespace:
    """``arm.device_config``：板载 DEVICE_CONFIG 记录（JSON ``{mounting}``）读写。

    **板上权威**：有记录时读以板上为准；无记录时 ``mounting`` 回落 ``connect(mounting=...)``
    初值。赋值**落板**（写板须持控制权；只要求持有会话，不要求失能态），并同步运行期控制器的
    安装方式。

    **设备名已退役**：只有 ``mounting`` 一个字段。板上旧记录可能仍带 ``name``
    等未知键——读取时**容忍并忽略**，写入只落 ``{mounting}``（不回写旧键）。
    """

    def __init__(self, owner: "Arm", storage: DeviceStorage) -> None:
        self._owner = owner
        self._storage = storage

    def _read(self) -> dict:
        return _read_device_config(self._storage) or {}

    def _write(self, cfg: dict) -> None:
        blob = json.dumps(cfg, sort_keys=True, ensure_ascii=False).encode("utf-8")
        with self._owner._lock:
            self._storage.write_record(StorageRecord.DEVICE_CONFIG, blob)

    @property
    def mounting(self) -> str:
        stored = self._read().get("mounting")
        if isinstance(stored, str) and stored:
            return stored
        return self._owner._default_mounting

    @mounting.setter
    def mounting(self, value) -> None:
        canonical = normalize_mounting(value)
        # 只写 ``{mounting}``：不保留/回写旧记录里的未知键（如退役的 name）。
        self._write({"mounting": canonical})
        with self._owner._lock:
            self._owner._controller.set_mounting(canonical)
        self._owner.mounting = canonical
        self._owner._default_mounting = canonical


class _DeviceDataNamespace:
    """``arm.device_data``：整机板载数据**备份 / 恢复**。

    导出（:meth:`export_bytes`）：单个 JSON 对象（**UTF-8 字节，非 zip**）::

        {"schema": "d2arm.device-data.v1",
         "exported_at": <iso8601>,
         "records": {"device_config": {"mounting": ...},
                     "teach": {"<槽号>": "<base64(7170B 小端二进制)>", ...}}}

    仅含**板上存在**的记录；teach 仅已用槽（count>0）。``device_config`` 即 ``{mounting}``
    （设备名已退役）。**负载记录不进导入导出**。束 schema 字段名仍
    ``d2arm.device-data.v1``。

    导入（:meth:`import_bytes`）：按同 schema 校验（未知 schema 拒绝、teach 槽 base64 解码后须
    恰为 7170 B）后逐记录写板（**只写 teach + device_config**）；**只写束内出现的记录**，
    未出现的记录不动。**旧束里的 ``name`` / ``payload`` 等未知键宽容忽略**（不报错、不回写）。
    **写板须持控制权**。备份走纯内存，不落主机文件。
    """

    def __init__(self, owner: "Arm", storage: DeviceStorage) -> None:
        self._owner = owner
        self._storage = storage

    def _read_json_record(self, rec: StorageRecord, label: str, hint: str) -> dict | None:
        """读一条 JSON 记录并解码；无记录返回 ``None``。

        记录内容**非 UTF-8 / 非 JSON / 非对象**时抛**可读** ``DeviceStorageError``（指名记录 +
        原因 + 建议），不把裸 ``UnicodeDecodeError``/``JSONDecodeError`` 漏给上层
        （真机第 7 项：板上被异常写入二进制时后端曾 500）。
        """
        if self._storage.info_record(rec) is None:
            return None
        raw = self._storage.read_record(rec)
        try:
            obj = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise DeviceStorageError(
                f"{label} 记录损坏：内容不是有效 JSON（可能被异常写入）；"
                f"请在上位机清除{hint}后重试"
            ) from exc
        if not isinstance(obj, dict):
            raise DeviceStorageError(
                f"{label} 记录损坏：内容不是 JSON 对象（可能被异常写入）；"
                f"请在上位机清除{hint}后重试"
            )
        return obj

    def export_bytes(self) -> bytes:
        records: dict = {}
        teach: dict[str, str] = {}
        for slot in range(SLOT_COUNT):
            rec = StorageRecord.TEACH_SLOT(slot)
            if self._storage.info_record(rec) is None:
                continue
            raw = self._storage.read_record(rec)
            if len(raw) < 2 or struct.unpack_from("<H", raw, 0)[0] == 0:
                continue  # 空槽（count==0）
            teach[str(slot)] = base64.b64encode(raw).decode("ascii")
        if teach:
            records["teach"] = teach

        # 负载记录**不进导入导出**：records 只含 teach + device_config。

        # device_config 恒导出**当前有效值**（板上有记录用它，否则回落连接初值），
        # 保证备份是一份完整可恢复的设备配置。**损坏即报错**（不静默回落默认值）。
        # 只导出 ``{mounting}``；旧记录里的 name 等未知键忽略。
        cfg = self._read_json_record(StorageRecord.DEVICE_CONFIG, "DEVICE_CONFIG", "设备配置") or {}
        stored_mount = cfg.get("mounting")
        records["device_config"] = {
            "mounting": stored_mount if isinstance(stored_mount, str) and stored_mount
            else self._owner._default_mounting,
        }

        bundle = {"schema": DATA_SCHEMA, "exported_at": _now_iso(), "records": records}
        return json.dumps(bundle, ensure_ascii=False).encode("utf-8")

    def import_bytes(self, data: bytes) -> dict:
        """恢复一份 :meth:`export_bytes` 产物；返回 ``{"written": n}``（写成功的记录数）。"""
        if not isinstance(data, (bytes, bytearray)):
            raise DeviceStorageError("导入数据须为 bytes")
        try:
            bundle = json.loads(bytes(data).decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise DeviceStorageError(f"导入数据非法（非 JSON）：{exc}") from exc
        if not isinstance(bundle, dict) or bundle.get("schema") != DATA_SCHEMA:
            raise DeviceStorageError("导入数据 schema 不符")
        records = bundle.get("records")
        if not isinstance(records, dict):
            raise DeviceStorageError("导入数据 records 非法")

        # 先**全部校验**再写板：坏束不得留下半写状态。
        pending: list[tuple[StorageRecord, bytes]] = []
        if "device_config" in records:
            cfg = records["device_config"]
            if not isinstance(cfg, dict):
                raise DeviceStorageError("device_config 非法（非对象）")
            # 只落 ``{mounting}``；旧束里的 name 等未知键**忽略**（不报错、不回写）。
            mounting = cfg.get("mounting")
            normalized = {"mounting": mounting} if isinstance(mounting, str) and mounting else {}
            pending.append((StorageRecord.DEVICE_CONFIG, _json_bytes(normalized)))
        # 负载记录**不进导入**：旧束里的 ``payload`` 键**宽容忽略**（不报错、不写板）。
        teach = records.get("teach")
        if teach is not None:
            if not isinstance(teach, dict):
                raise DeviceStorageError("teach 非法（非对象）")
            for key, token in teach.items():
                rec = self._teach_record(key)
                if not isinstance(token, str):
                    raise DeviceStorageError(f"teach 槽 {key} 非法（非 base64 串）")
                try:
                    raw = base64.b64decode(token, validate=True)
                except (ValueError, TypeError) as exc:
                    raise DeviceStorageError(f"teach 槽 {key} base64 解码失败：{exc}") from exc
                if not _teach_record_valid(raw):
                    raise DeviceStorageError(
                        f"teach 槽 {key} 记录非法（长度 {len(raw)}B 不是有效示教记录）"
                    )
                pending.append((rec, raw))

        with self._owner._lock:
            for rec, raw in pending:
                self._storage.write_record(rec, raw)
        return {"written": len(pending)}

    @staticmethod
    def _teach_record(key) -> StorageRecord:
        try:
            slot = int(key)
        except (TypeError, ValueError) as exc:
            raise DeviceStorageError(f"teach 槽号非法：{key!r}") from exc
        if not (0 <= slot < SLOT_COUNT):
            raise DeviceStorageError(f"teach 槽号越界：{slot}")
        return StorageRecord.TEACH_SLOT(slot)


class _UpgradeNamespace:
    """``arm.upgrade``：委托 ``upgrade_firmware``（仅 UDP）。"""

    def __init__(self, owner: "Arm") -> None:
        self._owner = owner

    def run(self, image_path, *, filename=None, progress=None, cancel=None):
        """执行一次固件升级（**长操作**；持主锁，与所有设备命令互斥）。

        **升级期间自动让出控制权、结束后自动重连，设备会重启。** 升级的前置阶段要自行取控制权，
        而设备同一时刻只允许一个客户端持有控制权——若本连接仍持权，升级的取权会被拒
        （``DENIED_BUSY``）。因此：先 ``runtime.release()`` 让出控制权（停发流、保持链路打开）→
        执行升级（设备随即复位进入 Bootloader，连接短暂中断）→ **无论成败**都按原连接参数
        ``reconnect()`` 重建链路与取权（设备升级后已重启，链路标识已变）。

        升级要求设备处于**已失能**状态（调用前先 ``arm.disable()``）。升级中/后设备会重启，
        期间不要再下发运动。失败时**重抛升级自身的异常**（重连失败不影响原异常）。
        """
        kwargs = {}
        if self._owner._bootloader_ip is not None:
            kwargs["bootloader_ip"] = self._owner._bootloader_ip
        if self._owner._bootloader_port is not None:
            kwargs["bootloader_port"] = self._owner._bootloader_port
        with self._owner._lock:
            # 1) 让出控制权（保持链路开）：否则升级前置的 ACQUIRE 会被 DENIED_BUSY 拒绝。
            if self._owner._device.held:
                try:
                    self._owner._runtime.release()
                except (LinkError, SessionError):
                    pass
            try:
                # 2) 升级（设备会复位进 Bootloader 再回到 App）。
                return upgrade_firmware(
                    self._owner._device,
                    image_path,
                    filename=filename,
                    progress=progress,
                    cancel=cancel,
                    **kwargs,
                )
            finally:
                # 3) 无论成败都尽力重连（设备已重启，boot_id 已变）；重连失败不得掩盖升级结果/异常。
                try:
                    self._owner.reconnect()
                except Exception:  # noqa: BLE001 — 重连尽力而为
                    pass

    def __call__(self, image_path, **kwargs):
        return self.run(image_path, **kwargs)


class Arm:
    """高层机械臂句柄：顶层使能/停止/关闭 + ``robot``/``state``/``motion``/``gripper``/
    ``teach``/``payloads``/``device_config``/``device_data``/``upgrade`` 命名空间（均为薄委托）。"""

    def __init__(
        self,
        device: Device,
        runtime: ArmRuntime,
        controller: MotionController,
        *,
        target: str,
        mounting: str = "upright",
        teach_store: TeachStore | None = None,
        payload_store: PayloadStore | None = None,
        storage: DeviceStorage | None = None,
        bootloader_ip: str | None = None,
        bootloader_port: int | None = None,
    ) -> None:
        self._device = device
        self._runtime = runtime
        self._controller = controller
        self._target = target
        self.mounting = mounting
        # 板上无 DEVICE_CONFIG 记录时 ``device_config.mounting`` 的回落初值。
        self._default_mounting = mounting
        self._payload_store = payload_store
        # 存储写只要求持有会话：直连底层 DeviceStorage，不再包使能态护栏。
        self._storage = storage if storage is not None else DeviceStorage(device)
        self._bootloader_ip = bootloader_ip
        self._bootloader_port = bootloader_port

        self._lock = threading.RLock()
        self._handles: list[MotionHandle] = []
        self._subscribers: list = []
        self._sub_lock = threading.Lock()
        self._callback_errors = 0
        self._closed = False
        # 已确认失能标志：避免 __exit__ 的 disable() 之后 close() 再发一次 SET_ENABLE(0)。
        self._disabled_confirmed = False

        # 遥测分发：Device 只有一个 on_telemetry 槽，在此多路复用给订阅者。
        device.on_telemetry = self._dispatch_telemetry

        self.robot = _RobotNamespace(self)
        self.state = _StateNamespace(self)
        self.motion = _MotionNamespace(self)
        self.gripper = _GripperNamespace(self)
        self.teach = _TeachNamespace(self, teach_store)
        self.payloads = _PayloadsNamespace(self)
        self.device_config = _DeviceConfigNamespace(self, self._storage)
        self.device_data = _DeviceDataNamespace(self, self._storage)
        self.upgrade = _UpgradeNamespace(self)

    # -- 上下文管理器 -----------------------------------------------------

    def __enter__(self) -> "Arm":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        # best-effort 失能 + 断链；**吞二次异常**，绝不掩盖 with 体内主异常。
        try:
            if not self._closed:
                self.disable()  # 成功后置 _disabled_confirmed ⇒ close() 不再重复失能
        except Exception:  # noqa: BLE001 — 收尾失败不得掩盖 with 体内主异常
            pass
        try:
            self.close()
        except Exception:  # noqa: BLE001
            pass
        return False

    # -- 使能 / 失能 ------------------------------------------------------

    @property
    def enabled(self) -> bool | None:
        """由最新遥测判是否使能：``execution_state ∈ {HOLD,RUNNING}``。

        判据与实战口径一致（**不含** ``enabled_mask`` 项）。
        无遥测 / 快照不新鲜时返回 ``None``（**未知**，不谎报 False）。
        """
        snap = self._device.telemetry()
        if snap is None or not snap.fresh(self._runtime.fresh_s):
            return None
        return self._is_enabled_snap(snap)

    def enable(self, timeout: float = DEFAULT_ENABLE_TIMEOUT_S) -> None:
        """使能并轮询遥测确认 ``execution_state ∈ {HOLD,RUNNING}``。

        ``set_enable(True)`` 内部先发锚定帧。设备显式拒绝或未在 ``timeout``
        内确认 ⇒ 抛 :class:`EnableError`（``.result``/``.observed`` 可读，含建议）。

        **早退只认不早于本次调用的快照**：若拿到的快照早于本次 ``enable()``
        调用（设备可能已复位到 PROBING/DISABLED 而客户端仍见旧 es=2），不得早退——照走完整
        ``set_enable`` + 确认序列，避免"以为上电了"。
        """
        with self._lock:
            started = time.monotonic()
            snap = self._device.telemetry()
            if self._is_enabled_snap(snap) and snap is not None and snap.recv_monotonic >= started:
                return
            resp = self._runtime.set_enable(True)
            code = int(getattr(resp, "result", 0))
            if code != int(P.Result.OK):
                raise EnableError(f"使能被拒绝：{_readable_result(code)}", result=code)
            self._await_confirm(self._is_enabled_snap, timeout, "使能")
            self._disabled_confirmed = False

    def disable(self, timeout: float = DEFAULT_ENABLE_TIMEOUT_S) -> None:
        """失能并轮询遥测确认 ``execution_state == DISABLED`` 且 ``enabled_mask == 0``。

        **早退与 ``enable()`` 对称**：仅当快照 ``recv_monotonic >= 本次调用时刻``
        （该帧不早于本次调用）且为新鲜 DISABLED 时才早退；否则照走完整 ``set_enable(False)`` +
        确认。避免「新鲜但早于调用」的旧 DISABLED 快照导致早退不发帧、且误置
        ``_disabled_confirmed=True``。
        """
        with self._lock:
            started = time.monotonic()
            snap = self._device.telemetry()
            if self._is_disabled_snap(snap) and snap is not None and snap.recv_monotonic >= started:
                self._disabled_confirmed = True
                return
            resp = self._runtime.set_enable(False)
            code = int(getattr(resp, "result", 0))
            if code != int(P.Result.OK):
                raise EnableError(f"失能被拒绝：{_readable_result(code)}", result=code)
            self._await_confirm(self._is_disabled_snap, timeout, "失能")
            self._disabled_confirmed = True

    def _is_enabled_snap(self, snap) -> bool:
        if snap is None or not snap.fresh(self._runtime.fresh_s):
            return False
        return int(snap.execution_state) in _ENABLED_STATES

    def _is_disabled_snap(self, snap) -> bool:
        if snap is None or not snap.fresh(self._runtime.fresh_s):
            return False
        return (
            int(snap.execution_state) == int(P.Execution_state.DISABLED)
            and int(snap.enabled_mask) == 0
        )

    def _await_confirm(self, pred, timeout: float, action: str) -> None:
        deadline = time.monotonic() + float(timeout)
        while True:
            snap = self._device.telemetry()
            if pred(snap):
                return
            if time.monotonic() >= deadline:
                raise EnableError(
                    self._timeout_message(action, snap), observed=self._observed_text(snap)
                )
            time.sleep(_ENABLE_CONFIRM_POLL_S)

    @staticmethod
    def _observed_text(snap) -> str:
        if snap is None:
            return "尚未收到遥测"
        return (
            f"execution_state={_exec_state_name(snap.execution_state)}"
            f"({int(snap.execution_state)})，enabled_mask=0x{int(snap.enabled_mask):02X}，"
            f"age={snap.age():.3f}s"
        )

    @classmethod
    def _timeout_message(cls, action: str, snap) -> str:
        return (
            f"{action}未在时限内确认：最后观测 {cls._observed_text(snap)}；"
            "请检查设备使能/急停状态与链路，或重试"
        )

    # -- 停止 / 关闭 ------------------------------------------------------

    def stop(self) -> None:
        """取消当前动作 + 切保持：进入中的 ServoJ 先 ``servoj_end``，再取消已跟踪句柄，最后
        ``runtime.start_hold()``。兜底动作（返回 ``None``，与其余命令一致），收尾失败不抛出。"""
        with self._lock:
            if self._controller.servoj_active():
                try:
                    self._controller.servoj_end()
                except Exception:  # noqa: BLE001 — 停止是安全兜底
                    pass
            for handle in self._active_handles():
                try:
                    handle.cancel()
                except Exception:  # noqa: BLE001
                    pass
            try:
                self._runtime.start_hold()
            except (LinkError, SessionError, TransportError, GravityError):
                pass

    def close(self) -> None:
        """失能（best-effort）→ release → close；幂等，可重复调用。"""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._disable_best_effort()
            # 关链前把仍在让位窗口里的 AUTO 同步送出，避免设备锁存任务橙色。
            try:
                self._controller.flush_task_led()
            except Exception:  # noqa: BLE001 — 灯效收尾不得阻断关链
                pass
            try:
                self._runtime.disconnect(release=True)
            except (LinkError, SessionError, TransportError):
                pass

    def reconnect(self) -> "Arm":
        """用保留的连接参数整链路重建：release→close→重连→重握手→重取控制权。

        与 :func:`connect` 同款的失败清理：重连段（open/hello/acquire）任一失败 ⇒ 先
        ``close()`` 再抛，绝不留半开链路；``hello`` 复用同一可读的 ``ProtocolVersionError``
        包装。重取控制权走 ``runtime.acquire()``（会让供给器 ``streamer.start()``，与底层
        ``_try_reacquire`` 同语义）。
        """
        with self._lock:
            if self._closed:
                raise SessionError("链路已关闭，无法重连")
            try:
                self._controller.flush_task_led()
            except Exception:  # noqa: BLE001 — 灯效收尾不得阻断重连
                pass
            try:
                self._runtime.disconnect(release=True)
            except (LinkError, SessionError, TransportError):
                pass
            try:
                self._device.open()
                _hello_readable(self._device)
                self._runtime.acquire()
            except BaseException:
                try:
                    self._device.close()
                except Exception:  # noqa: BLE001 — 收尾失败不得掩盖重连主异常
                    pass
                raise
            self._disabled_confirmed = False
            return self

    def _disable_best_effort(self) -> None:
        # 已确认失能（如 __exit__ 的 disable() 成功）则跳过，避免重复 SET_ENABLE(0)。
        if self._disabled_confirmed:
            return
        try:
            if self._device.is_open and self._device.held:
                self._runtime.set_enable(False)
                self._disabled_confirmed = True
        except (LinkError, SessionError, TransportError):
            pass

    # -- 句柄跟踪 / 订阅 / 遥测分发 ---------------------------------------

    def _track(self, handle):
        if isinstance(handle, MotionHandle):
            with self._lock:
                self._handles = [h for h in self._handles if h.status is MotionStatus.STARTED]
                self._handles.append(handle)
        return handle

    def _active_handles(self) -> list[MotionHandle]:
        with self._lock:
            self._handles = [h for h in self._handles if h.status is MotionStatus.STARTED]
            return list(self._handles)

    def _subscribe(self, callback) -> None:
        if not callable(callback):
            raise TypeError("subscribe 回调必须可调用")
        with self._sub_lock:
            if callback not in self._subscribers:
                self._subscribers.append(callback)

    def _unsubscribe(self, callback) -> None:
        with self._sub_lock:
            try:
                self._subscribers.remove(callback)
            except ValueError:
                pass

    def _dispatch_telemetry(self, snap) -> None:
        with self._sub_lock:
            subscribers = list(self._subscribers)
        for callback in subscribers:
            try:
                callback(snap)
            except Exception:  # noqa: BLE001 — 回调异常不得打断遥测流（忽略 + 计数）
                self._callback_errors += 1

    def __repr__(self) -> str:
        return f"Arm(target={self._target!r}, mounting={self.mounting!r}, closed={self._closed})"
