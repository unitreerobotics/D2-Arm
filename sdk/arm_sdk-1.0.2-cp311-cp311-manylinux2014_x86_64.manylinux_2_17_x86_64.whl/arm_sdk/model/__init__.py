"""`model/` 层：几何模型加载 + 设备/模型一致性 + 重力参数资产。

单一来源是 `models/urdf/manifest.json`；本包通过共享解析器
`models/model_manifest.py` 读取，不写死版本号、不另建第二份 URDF 定义。
"""

from __future__ import annotations

from .arm_model import ArmModel, ModelError, ModelJoint, active_model_id, load_model
from .consistency import (
    ModelMismatchError,
    expected_geometry_id,
    verify_against_device,
    verify_device_geometry,
)
from .gravity_asset import GravityParams, load_gravity_params

__all__ = [
    "ArmModel",
    "ModelJoint",
    "ModelError",
    "active_model_id",
    "load_model",
    "ModelMismatchError",
    "expected_geometry_id",
    "verify_device_geometry",
    "verify_against_device",
    "GravityParams",
    "load_gravity_params",
]
